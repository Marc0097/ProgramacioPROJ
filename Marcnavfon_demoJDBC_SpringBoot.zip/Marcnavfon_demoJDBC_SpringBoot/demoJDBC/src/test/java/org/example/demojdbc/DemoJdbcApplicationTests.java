package org.example.demojdbc;

import org.example.demojdbc.model.Producto;
import org.example.demojdbc.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class DemoJdbcApplicationTests {

    @Autowired
    ProductoRepository repo;

    @BeforeEach
    void setUp() {
        repo.borrarTodos();
        repo.insertar(new Producto(null, "book", 1200.0, 10));
        repo.insertar(new Producto(null, "pencil", 20.0, 100));
    }

    @Test
    void buscarTodos() {
        List<Producto> productos = repo.buscarTodos();
        assertEquals(2, productos.size());
    }

    @Test
    void buscarUno() {
        Producto p = repo.buscarUno("pencil");
        assertNotNull(p);
        assertEquals("pencil", p.getNombre());
    }

    @Test
    void insertar() {
        repo.insertar(new Producto(null, "teclado", 30.0, 50));
        List<Producto> productos = repo.buscarTodos();
        assertEquals(3, productos.size());
    }

    @Test
    void borrarPorNombre() {
        repo.borrar(new Producto(null, "book", 30.0, 50));
        List<Producto> productos = repo.buscarTodos();
        assertEquals(1, productos.size());
    }
}
