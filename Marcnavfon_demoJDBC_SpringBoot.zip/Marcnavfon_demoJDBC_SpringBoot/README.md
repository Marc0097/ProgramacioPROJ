# 📦 demoJDBC_SpringBoot - CRUD Producto

## 🚀 Descripción

Este proyecto es un ejemplo de aplicación Spring Boot que utiliza **JDBC** para realizar operaciones CRUD sobre la entidad:  
- **Producto**

La conexión se realiza a una base de datos MySQL y se muestra cómo implementar el acceso a datos utilizando `JdbcTemplate`. Además, incluye tests automatizados con JUnit para verificar el correcto funcionamiento de las operaciones.

---

## 🛠️ Tecnologías usadas

- Java 17+  
- Spring Boot 3+  
- Spring JDBC (`JdbcTemplate`)  
- MySQL  
- JUnit 5  
- Maven

---

## ⚙️ Configuración previa

1. **Crear base de datos MySQL**  
   - Accede a tu servidor MySQL usando una herramienta como MySQL Workbench, phpMyAdmin o línea de comandos.  
   - Crea una base de datos dedicada para este proyecto (por ejemplo, llamada `productosdb`).  
   - Dentro de esta base de datos, crea la tabla `productos` con los campos necesarios según el modelo del proyecto (id, nombre, apellidos, edad).  
   - Asegúrate de que el usuario que usarás para conectar tenga los permisos adecuados para operar sobre esta base de datos.

2. **Configurar conexión en `application.properties`**

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/tu_base_de_datos
spring.datasource.username=tu_usuario
spring.datasource.password=tu_contraseña
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```
## 📦 Importar proyecto en tu IDE

- Abre el proyecto en tu IDE favorito (IntelliJ IDEA, Eclipse, VSCode).  
- Asegúrate de que Maven descargue todas las dependencias correctamente.  

---

## 📚 Uso y ejecución

### Ejecutar la aplicación

Desde la raíz del proyecto, ejecuta:

```bash
./mvnw spring-boot:run
